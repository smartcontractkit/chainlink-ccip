# crib-chainlink-cluster

![Version: 1.5.1](https://img.shields.io/badge/Version-1.5.1-informational?style=flat-square) ![AppVersion: 2.10.0](https://img.shields.io/badge/AppVersion-2.10.0-informational?style=flat-square)

Chainlink nodes cluster testing with CRIB ephemeral environment.

## How it works?
### CRIB CLI Flow

```mermaid
sequenceDiagram
participant D as DevEnvironment
participant E as ECR
participant K as Kubernetes

loop Iterate on the code
D->>D: Make some local changes in the repository
D->>E: `devspace build` - Builds and pushes Devspace Image
D->>K: `devspace deploy` - Deploys to "crib-[your-name]" namesapce in kubernetes
loop wait
D->>K: Query and wait for deployment to finish
end
end

```

### CRIB PR Flow

*NOTE*: This is currently in alpha and not officially supported yet. Use at your own risk.
#### Provision CRIB Env

```mermaid
sequenceDiagram
participant D as DevEnvironment
participant G as Github
participant E as ECR
participant A as ArgoCD
participant K as Kubernetes

D->>G: Push local changes to the branch <br> and open PR with "crib" label
G->>A: Github notifies ArgoCD via webhook <br> about "crib" label added
G->>G: GHA builds "crib-chainlink-untrusted" image <br> and tag it with "sha-[head_short_sha_7]"
A->>K: ArgoCD "appset" deploys CRIB <br> to the "crib-chainlink-[PR Number]" namespace
Note over A,G:ArgoCD will currently try to do its initial sync before the Docker <br> is built/published. This causes an error deploying the pod with <br> the updated image but will eventually be successful.  <br> This should be mitigated by RE-2095.
G->>E: GHA pushes image to ECR

```

#### Delete CRIB Env
```mermaid
sequenceDiagram
participant D as DevEnvironment
participant G as Github
participant A as ArgoCD
participant K as Kubernetes

D->>G: Remove "crib" label from the PR
G->>A: Github sends webhook and notify ArgoCD about deleted label
A->>A: ArgoCD triggers sync, to immediately destroy CRIB environment

```

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://grafana.github.io/helm-charts | grafana | 7.3.2 |
| https://grafana.github.io/helm-charts | tempo | 1.7.2 |
| https://open-telemetry.github.io/opentelemetry-helm-charts | opentelemetry-collector | 0.82.0 |
| https://www.mock-server.com | mockserver | 5.14.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | string | `nil` |  |
| chainlink.enabled | bool | `true` |  |
| chainlink.global.overridesToml | string | `nil` |  |
| chainlink.global.toml | string | `nil` |  |
| chainlink.networkPolicy.extraIngressSelectors | list | `[]` |  |
| chainlink.nodes.node1.image | string | `"public.ecr.aws/chainlink/chainlink:latest"` |  |
| chainlink.nodes.node1.resources.limits.cpu | string | `"2000m"` |  |
| chainlink.nodes.node1.resources.limits.memory | string | `"2048Mi"` |  |
| chainlink.nodes.node1.resources.requests.cpu | string | `"300m"` |  |
| chainlink.nodes.node1.resources.requests.memory | string | `"1048Mi"` |  |
| chainlink.nodes.node2 | object | `{}` |  |
| chainlink.nodes.node3 | object | `{}` |  |
| chainlink.nodes.node4 | object | `{}` |  |
| chainlink.nodes.node5 | object | `{}` |  |
| chainlink.p2p_port | int | `6690` |  |
| chainlink.podSecurityContext.fsGroup | int | `14933` |  |
| chainlink.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| chainlink.securityContext.readOnlyRootFilesystem | bool | `false` |  |
| chainlink.securityContext.runAsGroup | int | `14933` |  |
| chainlink.securityContext.runAsNonRoot | bool | `true` |  |
| chainlink.securityContext.runAsUser | int | `14933` |  |
| chainlink.web_port | int | `6688` |  |
| db.enabled | bool | `true` |  |
| db.image | string | `"postgres:15.6"` |  |
| db.podSecurityContext.fsGroup | int | `999` |  |
| db.resources.limits.cpu | int | `1` |  |
| db.resources.limits.memory | string | `"1024Mi"` |  |
| db.resources.requests.cpu | string | `"250m"` |  |
| db.resources.requests.memory | string | `"256Mi"` |  |
| db.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| db.securityContext.readOnlyRootFilesystem | bool | `false` |  |
| db.securityContext.runAsGroup | int | `999` |  |
| db.securityContext.runAsNonRoot | bool | `true` |  |
| db.securityContext.runAsUser | int | `999` |  |
| db.statefulSet.capacity | string | `"2Gi"` |  |
| db.statefulSet.enabled | bool | `false` |  |
| db.statefulSet.storageClassName | string | `"gp3"` |  |
| geth.blocktime | int | `1` |  |
| geth.chains[0].networkId | int | `1337` |  |
| geth.chains[1].networkId | int | `2337` |  |
| geth.enabled | bool | `true` |  |
| geth.httpRpcPort | int | `8544` |  |
| geth.networkPolicy.extraIngressSelectors | list | `[]` |  |
| geth.podSecurityContext.fsGroup | int | `999` |  |
| geth.resources.limits.cpu | int | `1` |  |
| geth.resources.limits.memory | string | `"1024Mi"` |  |
| geth.resources.requests.cpu | string | `"250m"` |  |
| geth.resources.requests.memory | string | `"256Mi"` |  |
| geth.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| geth.securityContext.readOnlyRootFilesystem | bool | `false` |  |
| geth.securityContext.runAsGroup | int | `999` |  |
| geth.securityContext.runAsNonRoot | bool | `true` |  |
| geth.securityContext.runAsUser | int | `999` |  |
| geth.statefulSet.capacity | string | `"2Gi"` |  |
| geth.statefulSet.enabled | bool | `false` |  |
| geth.statefulSet.storageClassName | string | `"gp3"` |  |
| geth.version | string | `"v1.12.0"` |  |
| geth.wsRpcPort | int | `8546` |  |
| grafana.datasources."datasources.yaml".apiVersion | int | `1` |  |
| grafana.datasources."datasources.yaml".datasources[0].access | string | `"proxy"` |  |
| grafana.datasources."datasources.yaml".datasources[0].basicAuth | bool | `false` |  |
| grafana.datasources."datasources.yaml".datasources[0].editable | bool | `false` |  |
| grafana.datasources."datasources.yaml".datasources[0].isDefault | bool | `true` |  |
| grafana.datasources."datasources.yaml".datasources[0].jsonData.httpMethod | string | `"GET"` |  |
| grafana.datasources."datasources.yaml".datasources[0].jsonData.serviceMap.datasourceUid | string | `"prometheus"` |  |
| grafana.datasources."datasources.yaml".datasources[0].name | string | `"Tempo"` |  |
| grafana.datasources."datasources.yaml".datasources[0].orgId | int | `1` |  |
| grafana.datasources."datasources.yaml".datasources[0].type | string | `"tempo"` |  |
| grafana.datasources."datasources.yaml".datasources[0].uid | string | `"tempo"` |  |
| grafana.datasources."datasources.yaml".datasources[0].url | string | `"http://app-tempo:3100"` |  |
| grafana.datasources."datasources.yaml".datasources[0].version | int | `1` |  |
| grafana.enabled | bool | `true` |  |
| grafana.env.GF_AUTH_ANONYMOUS_ENABLED | string | `"true"` |  |
| grafana.env.GF_AUTH_ANONYMOUS_ORG_ROLE | string | `"Admin"` |  |
| grafana.env.GF_AUTH_DISABLE_LOGIN_FORM | string | `"true"` |  |
| grafana.env.GF_FEATURE_TOGGLES_ENABLE | string | `"traceqlEditor tempoSearch tempoServiceGraph"` |  |
| grafana.image.tag | string | `"10.4.1"` |  |
| grafana.rbac.create | bool | `false` |  |
| grafana.rbac.namespaced | bool | `true` |  |
| ingress.annotations | object | `{}` |  |
| ingress.enabled | bool | `false` |  |
| ingress.hosts[0].host | string | `"chainlink-node1.local"` |  |
| ingress.hosts[0].http.paths[0].backend.service.name | string | `"chainlink-node1"` |  |
| ingress.hosts[0].http.paths[0].backend.service.port.number | int | `6688` |  |
| ingress.hosts[0].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[0].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[1].host | string | `"chainlink-node2.local"` |  |
| ingress.hosts[1].http.paths[0].backend.service.name | string | `"chainlink-node2"` |  |
| ingress.hosts[1].http.paths[0].backend.service.port.number | int | `6688` |  |
| ingress.hosts[1].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[1].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[2].host | string | `"chainlink-node3.local"` |  |
| ingress.hosts[2].http.paths[0].backend.service.name | string | `"chainlink-node3"` |  |
| ingress.hosts[2].http.paths[0].backend.service.port.number | int | `6688` |  |
| ingress.hosts[2].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[2].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[3].host | string | `"chainlink-node4.local"` |  |
| ingress.hosts[3].http.paths[0].backend.service.name | string | `"chainlink-node4"` |  |
| ingress.hosts[3].http.paths[0].backend.service.port.number | int | `6688` |  |
| ingress.hosts[3].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[3].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[4].host | string | `"chainlink-node5.local"` |  |
| ingress.hosts[4].http.paths[0].backend.service.name | string | `"chainlink-node5"` |  |
| ingress.hosts[4].http.paths[0].backend.service.port.number | int | `6688` |  |
| ingress.hosts[4].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[4].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[5].host | string | `"chainlink-geth-http.local"` |  |
| ingress.hosts[5].http.paths[0].backend.service.name | string | `"geth"` |  |
| ingress.hosts[5].http.paths[0].backend.service.port.number | int | `8544` |  |
| ingress.hosts[5].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[5].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[6].host | string | `"chainlink-geth-ws.local"` |  |
| ingress.hosts[6].http.paths[0].backend.service.name | string | `"geth"` |  |
| ingress.hosts[6].http.paths[0].backend.service.port.number | int | `8546` |  |
| ingress.hosts[6].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[6].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[7].host | string | `"chainlink-mockserver.local"` |  |
| ingress.hosts[7].http.paths[0].backend.service.name | string | `"mockserver"` |  |
| ingress.hosts[7].http.paths[0].backend.service.port.number | int | `1080` |  |
| ingress.hosts[7].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[7].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.hosts[8].host | string | `"chainlink-grafana.local"` |  |
| ingress.hosts[8].http.paths[0].backend.service.name | string | `"grafana"` |  |
| ingress.hosts[8].http.paths[0].backend.service.port.number | int | `80` |  |
| ingress.hosts[8].http.paths[0].path | string | `"/"` |  |
| ingress.hosts[8].http.paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.ingressClassName | string | `"alb"` |  |
| mockserver.app.readOnlyRootFilesystem | bool | `false` |  |
| mockserver.app.runAsUser | int | `999` |  |
| mockserver.enabled | bool | `true` |  |
| mockserver.port | int | `1080` |  |
| mockserver.releasenameOverride | string | `"mockserver"` |  |
| mockserver.resources.limits.cpu | int | `1` |  |
| mockserver.resources.limits.memory | string | `"1024Mi"` |  |
| mockserver.resources.requests.cpu | string | `"100m"` |  |
| mockserver.resources.requests.memory | string | `"256Mi"` |  |
| mockserver.service.type | string | `"ClusterIP"` |  |
| networkPolicies.enabled | bool | `true` |  |
| networkPolicyDefault.egress | list | `[]` |  |
| networkPolicyDefault.ingress.allowCustomCidrs | bool | `false` |  |
| networkPolicyDefault.ingress.customCidrs | string | `nil` |  |
| nodeSelector | string | `nil` |  |
| opentelemetry-collector.command.name | string | `"otelcol"` |  |
| opentelemetry-collector.config.exporters.otlp.endpoint | string | `"app-tempo:4317"` |  |
| opentelemetry-collector.config.exporters.otlp.tls.insecure | bool | `true` |  |
| opentelemetry-collector.config.receivers.otlp.protocols.grpc.endpoint | string | `"${env:MY_POD_IP}:4317"` |  |
| opentelemetry-collector.config.receivers.otlp.protocols.http.endpoint | string | `"${env:MY_POD_IP}:4318"` |  |
| opentelemetry-collector.config.service.pipelines.traces.exporters[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.pipelines.traces.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.telemetry.logs.level | string | `"debug"` |  |
| opentelemetry-collector.enabled | bool | `true` |  |
| opentelemetry-collector.extraVolumeMounts[0].mountPath | string | `"/tracing"` |  |
| opentelemetry-collector.extraVolumeMounts[0].name | string | `"trace-data"` |  |
| opentelemetry-collector.extraVolumes[0].emptyDir | object | `{}` |  |
| opentelemetry-collector.extraVolumes[0].name | string | `"trace-data"` |  |
| opentelemetry-collector.image.repository | string | `"otel/opentelemetry-collector"` |  |
| opentelemetry-collector.image.tag | string | `"0.95.0"` |  |
| opentelemetry-collector.mode | string | `"deployment"` |  |
| opentelemetry-collector.podSecurityContext.fsGroup | int | `10001` |  |
| opentelemetry-collector.securityContext.runAsGroup | int | `10001` |  |
| opentelemetry-collector.securityContext.runAsNonRoot | bool | `true` |  |
| opentelemetry-collector.securityContext.runAsUser | int | `10001` |  |
| podAnnotations | string | `nil` |  |
| prometheusMonitor | bool | `true` |  |
| tempo.enabled | bool | `true` |  |
| tempo.image.tag | string | `"1.7.2"` |  |
| tempo.securityContext.runAsGroup | int | `10001` |  |
| tempo.securityContext.runAsNonRoot | bool | `true` |  |
| tempo.securityContext.runAsUser | int | `10001` |  |
| tempo.tempo.storage.trace.backend | string | `"local"` |  |
| tempo.tempo.storage.trace.local.path | string | `"/tmp/tempo/blocks"` |  |
| tempo.tempo.storage.trace.wal.path | string | `"/tmp/tempo/wal"` |  |
| tolerations | string | `nil` |  |
